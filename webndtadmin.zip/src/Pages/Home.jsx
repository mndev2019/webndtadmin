//import React from 'react'

const Home = () => {
  return (
   <>
      home
   </>
  )
}

export default Home