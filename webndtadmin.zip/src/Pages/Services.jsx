//import React from 'react'
import FormLabel from '../Layout/FormLabel'

const Services = () => {
    return (
        <>
            <section className='py-5'>
                <div className="container">
                    <div className="grid grid-cols-3 gap-3">
                        <div className="col-span-1">
                            <div className="w-full">
                                <FormLabel label="Service Title" />
                                <input
                                    placeholder='Enter Title'
                                    type="text"
                                    name="title"
                                    id="servicetitle"
                                    className="rounded w-full text-blue-gray-900 outline-none border border-blue-gray-200 text-sm p-2"
                                />
                            </div>
                        </div>
                        <div className="col-span-1">
                            <div className="w-full">
                                <FormLabel label="Service Icon" />
                                <input
                                    type="file"
                                    name="serviceicon"
                                    id="serviceicon"
                                    className="rounded w-full text-blue-gray-900 outline-none border border-blue-gray-200 text-sm p-2"
                                    required
                                />
                            </div>
                        </div>
                        <div className="col-span-1">
                            <div className="w-full">
                                <FormLabel label="Service Description" />
                                <input
                                    placeholder='Enter description'
                                    type="text"
                                    name="servicedescription"
                                    id="servicedescription"
                                    className="rounded w-full text-blue-gray-900 outline-none border border-blue-gray-200 text-sm p-2"
                                />
                            </div>
                        </div>
                        <div className="col-span-1 ">
                            <button
                                type="submit"
                                className="bg-primary text-xs uppercase font-y tracking-wider text-white px-5 rounded py-3 shadow-sm shadow-light"

                            >
                                SUBMIT
                            </button>
                        </div>
                    </div>
                    <div className="grid grid-cols-1">
                        <div className="col-span-1 mt-2">
                            <div className="w-full">
                                <table className='w-full'>
                                    <thead className=''>
                                        <tr className='*:text-start *:text-sm *:p-2 *:border *:border-blue-gray-200 bg-black text-white tablehead'>
                                            <th>
                                                Sr no
                                            </th>
                                            <th>
                                                Title
                                            </th>
                                            <th>
                                                Icon
                                            </th>
                                            <th>
                                                Description
                                            </th>
                                            <th>
                                                Action
                                            </th>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Services