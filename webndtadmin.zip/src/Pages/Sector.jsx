//import React from 'react'

import { CKEditor } from "@ckeditor/ckeditor5-react"
import FormLabel from "../Layout/FormLabel"
import ClassicEditor from "@ckeditor/ckeditor5-build-classic"

const Sector = () => {
    return (
        <>
            <section className="py-5">
                <div className="container">
                    <div className="grid grid-cols-3">
                        <div className="col-span-1">
                            <div className="w-full">
                                <FormLabel label="Sector Title" />
                                <input
                                    placeholder='Enter Title'
                                    type="text"
                                    name="title"
                                    id="sectortitle"
                                    className="rounded w-full text-blue-gray-900 outline-none border border-blue-gray-200 text-sm p-2"
                                />
                            </div>
                        </div>
                        <div className="col-span-3 mt-2">
                            <div className="w-full">
                                <FormLabel label="Sector description" />
                                <CKEditor
                                    editor={ClassicEditor}
                                    data=""
                                    className="rounded w-full text-blue-gray-900 outline-none border border-blue-gray-200 text-sm p-2"
                                />
                            </div>
                        </div>
                        <div className="col-span-1 mt-2 ">
                            <button
                                type="submit"
                                className="bg-primary text-xs uppercase font-y tracking-wider text-white px-5 rounded py-3 shadow-sm shadow-light"

                            >
                                SUBMIT
                            </button>
                        </div>

                    </div>
                </div>
            </section>
        </>
    )
}

export default Sector