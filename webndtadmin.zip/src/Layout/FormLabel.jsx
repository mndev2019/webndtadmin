/* eslint-disable react/prop-types */
//import React from 'react'

const FormLabel = (props) => {
  return (
   <>
      <label htmlFor='' className='text-xs  text-primary block mb-2 font-normal uppercase tracking-wider'>{props.label}</label>
   </>
  )
}

export default FormLabel