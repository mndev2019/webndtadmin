//import React from 'react'
import { Link, useLocation } from "react-router-dom"
import { GrServices } from "react-icons/gr";
import { FaChartArea } from "react-icons/fa";
const Sidebar = () => {
    const location = useLocation();
    return (
        <>
            <div className="w-full  h-[100%] overflow-x-hidden overflow-y-auto relative bg-primary  ">
                <ul className="*:py-1 px-3 *:text-sm *:font-light *:text-primary">
                    <li>
                        <Link to={'/services'} className='w-full py-1 ps-3 text-start block rounded-lg'>
                            <div className="w-full flex gap-3 items-center hover:bg-[#d8a28980] rounded-md">
                                <div className={`h-[40px] w-[40px] flex justify-center items-center rounded-md ${location.pathname === '/services' ? 'bg-black' : 'bg-[#faebd7b5] '}`}>
                                    <GrServices className={`text-xl  ${location.pathname === '/services' ? 'text-white' : 'text-black '}`} />

                                </div>
                                <div className={`font-bold text-[15px] text-white ${location.pathname === '/services' ? 'text-primary' : 'text-black'}`}>
                                    <p className={`font-bold text-[15px]  ${location.pathname === '/services' ? 'text-white' : 'text-black'}`}>  Services</p>
                                </div>
                            </div>
                        </Link>
                    </li>
                    <li>
                        <Link to={'/sector'} className='w-full py-1 ps-3 text-start block rounded-lg'>
                            <div className="w-full flex gap-3 items-center hover:bg-[#d8a28980] rounded-md">
                                <div className={`h-[40px] w-[40px] flex justify-center items-center rounded-md ${location.pathname === '/sector' ? 'bg-black' : 'bg-[#faebd7b5] '}`}>
                                    <FaChartArea className={`text-xl  ${location.pathname === '/sector' ? 'text-white' : 'text-black '}`} />

                                </div>
                                <div className={`font-bold text-[15px] text-white ${location.pathname === '/sector' ? 'text-primary' : 'text-black'}`}>
                                    <p className={`font-bold text-[15px]  ${location.pathname === '/sector' ? 'text-white' : 'text-black'}`}>  Sector</p>
                                </div>
                            </div>
                        </Link>
                    </li>
                </ul>
            </div>
        </>
    )
}

export default Sidebar