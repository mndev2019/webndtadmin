/* eslint-disable react/prop-types */
//import React from 'react'

const SectionTilte = (props) => {
  return (
   <>
       <h2 className="text-lg font-bold text-primary block mb-2">{props.title}</h2>     
   </>
  )
}

export default SectionTilte